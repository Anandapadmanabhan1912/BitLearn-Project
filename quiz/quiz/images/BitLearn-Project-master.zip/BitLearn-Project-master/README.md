![StackUp Banner]([https://tinkerhub.frappe.cloud/files/stackup%20banner.jpeg])
# Project Name
Long Description about project. This project do that. This project is awesome...
## Team members
1. Name [Embed personal github URL]
2. Name [Embed perosnal github URL]
## Team Id
Team id here
## Link to product walkthrough
[link to video]
## How it Works ?
1. Explaining the working of project
2. Embed video of project demo
## Libraries used
Library Name - Version
## How to configure
Instructions for setting up project
## How to Run
Instructions for running
