# Resources
This contain resources of technology stacks used in the project. 
